package com.mindtree.ShopBrandProductManagementSystem.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ShopBrandProductManagementSystem.dto.ProductDto;
import com.mindtree.ShopBrandProductManagementSystem.dto.ShopDto;
import com.mindtree.ShopBrandProductManagementSystem.entity.Brand;
import com.mindtree.ShopBrandProductManagementSystem.entity.Product;
import com.mindtree.ShopBrandProductManagementSystem.entity.Shop;
import com.mindtree.ShopBrandProductManagementSystem.exception.noBrandIdException;
import com.mindtree.ShopBrandProductManagementSystem.repository.BrandRepository;
import com.mindtree.ShopBrandProductManagementSystem.repository.ProductRepository;
import com.mindtree.ShopBrandProductManagementSystem.repository.ShopRepository;
import com.mindtree.ShopBrandProductManagementSystem.service.ShopBrandProductService;

@Service
public class ShopBrandProductServiceImpl implements ShopBrandProductService {

	@Autowired
	ShopRepository shoprepository;

	@Autowired
	BrandRepository brandrepository;

	@Autowired
	ProductRepository productrepository;

	@Override
	public ShopDto addDetailsToDB(ShopDto shopdto) {
		Shop shop=new Shop();
		Brand brand = new Brand();
		List<Product> products = new ArrayList<>();
		shop.setShopId(shopdto.getShopId());
		shop.setShopName(shopdto.getShopName());
		shoprepository.save(shop);
		for (ProductDto productdto : shopdto.getProductsdto()) {
			Product product=new Product();
			product.setProductId(productdto.getProductId());
			product.setProductName(productdto.getProductName());
			product.setProductPrice(productdto.getProductPrice());
			product.setShop(shop);
			brand.setBrandId(productdto.getBranddto().getBrandId());
			brand.setBrandName(productdto.getBranddto().getBrandName());
			product.setBrand(brand);
			products.add(product);
		}
		shop.setProducts(products);
		brand.setProducts(products);
		brandrepository.save(brand);
		return shopdto;
	}
	
	@Override
	public List<ProductDto> getAllProductsByBrand(int brand_id) throws noBrandIdException {
		int found=0;
		List<Brand> brands=brandrepository.findAll();
		List<ProductDto> productsdto=new ArrayList<>();
		for(Brand brand:brands) {
			if(brand.getBrandId()==brand_id) {
				
				found=1;
				for(Product product:brand.getProducts()) {
					if(product.getProductPrice()>100) {
						ProductDto productdto=new ProductDto();
						productdto.setProductId(product.getProductId());
						productdto.setProductName(product.getProductName());
						productdto.setProductPrice(product.getProductPrice());
						productsdto.add(productdto);
						
					}
				}
			}
		}
	
		if(found==0) {
			throw new noBrandIdException("brand id not found");
		}
		return productsdto;
	}

}
