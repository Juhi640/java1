package com.mindtree.ShopBrandProductManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.ShopBrandProductManagementSystem.dto.ProductDto;
import com.mindtree.ShopBrandProductManagementSystem.dto.ShopDto;
import com.mindtree.ShopBrandProductManagementSystem.exception.noBrandIdException;
import com.mindtree.ShopBrandProductManagementSystem.service.ShopBrandProductService;

@RestController
public class AppController {
	
@Autowired
ShopBrandProductService shopbrandproductservice;

@PostMapping("/shop")
public String addDetails(@RequestBody ShopDto shopdto) {
	shopbrandproductservice.addDetailsToDB(shopdto);
	String status="inserted successfully";
	return status;
}

@GetMapping("/products/{brand_id}")
public ResponseEntity<List<ProductDto>> getAllProducts(@PathVariable int brand_id ) throws noBrandIdException{
	List<ProductDto> productsdto=shopbrandproductservice.getAllProductsByBrand(brand_id);
	return new ResponseEntity<List<ProductDto>>(productsdto, HttpStatus.OK);
}

}
