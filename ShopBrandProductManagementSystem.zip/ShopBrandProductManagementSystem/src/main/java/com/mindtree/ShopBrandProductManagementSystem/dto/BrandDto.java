package com.mindtree.ShopBrandProductManagementSystem.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class BrandDto {

	private int brandId;

	private String brandName;

	@JsonIgnoreProperties("brandto")
	private List<ProductDto> productsdto;

	public BrandDto() {
		super();
	}

	public BrandDto(int brandId, String brandName, List<ProductDto> productsdto) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.productsdto = productsdto;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public List<ProductDto> getProductsdto() {
		return productsdto;
	}

	public void setProductsdto(List<ProductDto> productsdto) {
		this.productsdto = productsdto;
	}

	@Override
	public String toString() {
		return "BrandDto [brandId=" + brandId + ", brandName=" + brandName + ", productsdto=" + productsdto + "]";
	}

}
