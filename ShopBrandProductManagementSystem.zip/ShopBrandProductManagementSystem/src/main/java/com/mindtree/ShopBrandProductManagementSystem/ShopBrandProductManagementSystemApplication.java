package com.mindtree.ShopBrandProductManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopBrandProductManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopBrandProductManagementSystemApplication.class, args);
	}

}
