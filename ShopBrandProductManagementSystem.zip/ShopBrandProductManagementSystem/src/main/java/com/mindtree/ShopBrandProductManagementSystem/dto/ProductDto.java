package com.mindtree.ShopBrandProductManagementSystem.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class ProductDto {

	private int productId;

	private String productName;

	private int productPrice;

	@JsonIgnoreProperties("productsdto")
	private ShopDto shopdto;

	@JsonIgnoreProperties("productsdto")
	private BrandDto branddto;

	public ProductDto() {
		super();
	}

	public ProductDto(int productId, String productName, int productPrice, ShopDto shopdto, BrandDto branddto) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.shopdto = shopdto;
		this.branddto = branddto;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public ShopDto getShopdto() {
		return shopdto;
	}

	public void setShopdto(ShopDto shopdto) {
		this.shopdto = shopdto;
	}

	public BrandDto getBranddto() {
		return branddto;
	}

	public void setBranddto(BrandDto branddto) {
		this.branddto = branddto;
	}

	@Override
	public String toString() {
		return "ProductDto [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", shopdto=" + shopdto + ", branddto=" + branddto + "]";
	}

}
