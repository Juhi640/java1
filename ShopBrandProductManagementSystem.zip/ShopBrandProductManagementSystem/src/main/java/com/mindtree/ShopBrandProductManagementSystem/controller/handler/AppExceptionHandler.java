package com.mindtree.ShopBrandProductManagementSystem.controller.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.ShopBrandProductManagementSystem.controller.AppController;
import com.mindtree.ShopBrandProductManagementSystem.exception.noBrandIdException;

@RestControllerAdvice(assignableTypes = { AppController.class })
public class AppExceptionHandler {

	@ExceptionHandler(noBrandIdException.class)
	public ResponseEntity<String> serviceExceptionHandler(noBrandIdException e) {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
	}

}
