package com.mindtree.ShopBrandProductManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.ShopBrandProductManagementSystem.entity.Product;

@Repository
public interface ProductRepository extends JpaRepositoryImplementation<Product, Integer>{

}
