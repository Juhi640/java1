package com.mindtree.ShopBrandProductManagementSystem.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.ShopBrandProductManagementSystem.entity.Brand;

public class ShopDto {

	private int shopId;

	private String shopName;

	@JsonIgnoreProperties("shopdto")
	private List<ProductDto> productsdto;

	public ShopDto() {
		super();
	}

	public ShopDto(int shopId, String shopName, List<ProductDto> productsdto) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.productsdto = productsdto;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public List<ProductDto> getProductsdto() {
		return productsdto;
	}

	public void setProductsdto(List<ProductDto> productsdto) {
		this.productsdto = productsdto;
	}

	@Override
	public String toString() {
		return "ShopDto [shopId=" + shopId + ", shopName=" + shopName + ", productsdto=" + productsdto + "]";
	}

}
