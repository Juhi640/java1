package com.mindtree.ShopBrandProductManagementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.ShopBrandProductManagementSystem.dto.ProductDto;
import com.mindtree.ShopBrandProductManagementSystem.dto.ShopDto;
import com.mindtree.ShopBrandProductManagementSystem.exception.noBrandIdException;

@Service
public interface ShopBrandProductService {

	/**
	 * @param shopdto
	 * @return
	 */
	ShopDto addDetailsToDB(ShopDto shopdto); 
	
	/**
	 * @param brand_id
	 * @return
	 * @throws noBrandIdException
	 */
	List<ProductDto> getAllProductsByBrand(int brand_id) throws noBrandIdException;

}
