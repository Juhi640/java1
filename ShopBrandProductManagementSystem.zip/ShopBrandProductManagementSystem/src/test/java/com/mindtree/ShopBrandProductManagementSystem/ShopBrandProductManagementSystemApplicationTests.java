package com.mindtree.ShopBrandProductManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopBrandProductManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
